package org.example;

public  class TrafficFlowData {

    int morningPeak, afternoon, eveningPeak, night;

    TrafficFlowData(int morningPeak, int afternoon, int eveningPeak, int night) {
        this.morningPeak = morningPeak;
        this.afternoon = afternoon;
        this.eveningPeak = eveningPeak;
        this.night = night;
    }
}
